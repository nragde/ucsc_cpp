//#pragma once
#ifndef NINETYNINE_H
#define NINETYNINE_H

// Do the includes
#include "../util/util.h"

// Define the public and private methods for the object
class ninetynine {
	public:
            // There is a single method, that "sings" the beer bottles song
            void sing();
	private:
            
};

#endif
